package sample.views;

import java.util.ArrayList;
import java.util.List;
import sample.controllers.Menu;
import sample.controllers.StudentMountainList;
import sample.models.I_List;
import sample.models.I_Menu;
import sample.models.Student;
import sample.models.StudentMountain;
import sample.utils.Utils;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Wang
 */
public class MoutainHikingManagement {

    public static void main(String args[]) {
        I_Menu menu = new Menu();
        menu.addItem("1. Add new registration");
        menu.addItem("2. Display");
        menu.addItem("3. Save to file");
        menu.addItem("4. Delete student by ID");
        menu.addItem("5. Updete");
        menu.addItem("6. Find student by Name");
        menu.addItem("7: Find student by Campus");
        menu.addItem("8: Statistics of  registered number");
        menu.addItem("9: Quit");
        int choice;
        boolean cont = true;
        I_List list = new StudentMountainList();
        do {
            menu.showMenu();
            choice = menu.getChoice();
            switch (choice) {
                case 1:
                    list.create();
                    break;

                case 2:
                    list.display();
                    break;

                case 3:
                    list.saveToFile();
                    break;

                case 4:
                    String id = Utils.getString("Enter student ID to delete: ");
                    if (list.delete(id)) {
                        System.out.println("Successfully deleted the registration.");
                    }
                    break;

                case 5:
                    String newid = Utils.getString("Enter student ID to update: ");
                    if (list.update(newid)) {
                        System.out.println("Successfully update the registration.");
                    } else {
                        System.out.println("Failed to delete. ID not found.");
                    }
                    break;

                case 6:
                    String name = Utils.getString("Enter student NAME to find: ");
                    List<Object> results = list.search(name);

                    if (results != null && !results.isEmpty()) {
                        System.out.println("Found the following registrations: ");
                        System.out.println("------------------------------------------------------------------------------------------------------------------");
                        System.out.println("Student ID | Name                 | Phone        | Email                          | Peak Code       | Fee         ");
                        System.out.println("------------------------------------------------------------------------------------------------------------------");
                        for (Object o : results) {
                            System.out.println(o);
                        }
                        System.out.println("------------------------------------------------------------------------------------------------------------------");
                    } else {
                        System.out.println("No student have this name registered! ");
                    }
                    break;

                case 7:
                    String n = Utils.getString("Enter a Campus to find: ");
                    List<Object> result = list.filter(n);

                    if (result != null && !result.isEmpty()) {
                        System.out.println("Found the following registrations: ");
                        System.out.println("------------------------------------------------------------------------------------------------------------------");
                        System.out.println("Student ID | Name                 | Phone        | Email                          | Peak Code       | Fee         ");
                        System.out.println("------------------------------------------------------------------------------------------------------------------");
                        for (Object o : result) {
                            System.out.println(o);
                        }
                        System.out.println("------------------------------------------------------------------------------------------------------------------");
                    } else {
                        System.out.println("No student have registered under this campus! ");
                    }
                    break;

                case 8:
                    list.statistic(); // Tính toán thống kê
                    break;
                case 9:
                    boolean confirm = menu.confirmYesNo("Do you want to quit? (Y/N): ");
                    if (confirm) {
                        cont = false; // Thoát khỏi vòng lặp
                        System.out.println("Exiting the program. Goodbye!");
                    } else {
                        System.out.println("Continue using the program.");
                    }
                    break;
            }

        } while (choice >= 0 && choice <= 9 && cont);
    }
}
